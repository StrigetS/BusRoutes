package com.example.bus_routes2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "bus_routes.db";
    private static final int DATABASE_VERSION = 1;

    // таблица города
    private static final String TABLE_CITIES = "cities";
    private static final String COLUMN_CITY_ID = "city_id";
    private static final String COLUMN_CITY_NAME = "city_name";

    // таблица маршруты
    private static final String TABLE_ROUTES = "routes";
    private static final String COLUMN_ROUTE_ID = "route_id";
    private static final String COLUMN_FROM_CITY_ID = "from_city_id";
    private static final String COLUMN_TO_CITY_ID = "to_city_id";
    private static final String COLUMN_DEPARTURE_TIME = "departure_time";
    private static final String COLUMN_TRAVEL_TIME = "travel_time";
    private static final String COLUMN_PRICE = "price";

    // таблица история поездок
    private static final String TABLE_TRIP_HISTORY = "trip_history";
    private static final String COLUMN_HISTORY_ID = "history_id";
    private static final String COLUMN_FROM_CITY = "from_city";
    private static final String COLUMN_TO_CITY = "to_city";
    private static final String COLUMN_TRIP_DATE = "trip_date";
    private static final String COLUMN_BOOKING_DATE = "booking_date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // создание таблицы города
        String CREATE_CITIES_TABLE = "CREATE TABLE " + TABLE_CITIES + "("
                + COLUMN_CITY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_CITY_NAME + " TEXT UNIQUE"
                + ")";
        db.execSQL(CREATE_CITIES_TABLE);

        // ссоздание таблицы маршруты
        String CREATE_ROUTES_TABLE = "CREATE TABLE " + TABLE_ROUTES + "("
                + COLUMN_ROUTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_FROM_CITY_ID + " INTEGER,"
                + COLUMN_TO_CITY_ID + " INTEGER,"
                + COLUMN_DEPARTURE_TIME + " TEXT,"
                + COLUMN_TRAVEL_TIME + " INTEGER,"
                + COLUMN_PRICE + " INTEGER,"
                + "FOREIGN KEY(" + COLUMN_FROM_CITY_ID + ") REFERENCES " + TABLE_CITIES + "(" + COLUMN_CITY_ID + "),"
                + "FOREIGN KEY(" + COLUMN_TO_CITY_ID + ") REFERENCES " + TABLE_CITIES + "(" + COLUMN_CITY_ID + ")"
                + ")";
        db.execSQL(CREATE_ROUTES_TABLE);

        // создание таблицы история поездок
        String CREATE_TRIP_HISTORY_TABLE = "CREATE TABLE " + TABLE_TRIP_HISTORY + "("
                + COLUMN_HISTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_FROM_CITY + " TEXT,"
                + COLUMN_TO_CITY + " TEXT,"
                + COLUMN_TRIP_DATE + " TEXT,"
                + COLUMN_BOOKING_DATE + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(CREATE_TRIP_HISTORY_TABLE);

        // заполнение
        initializeData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIP_HISTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ROUTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CITIES);
        onCreate(db);
    }

    private void initializeData(SQLiteDatabase db) {
        // добвление городов
        String[] cities = {
                "Москва", "Санкт-Петербург", "Сочи", "Саратов", "Казань",
                "Екатеринбург", "Новосибирск", "Ростов-на-Дону", "Краснодар", "Волгоград"
        };

        ContentValues cityValues = new ContentValues();
        for (String city : cities) {
            cityValues.put(COLUMN_CITY_NAME, city);
            db.insert(TABLE_CITIES, null, cityValues);
        }

        // добавление маршрутов
        addRoute(db, "Москва", "Санкт-Петербург", "08:00", 8, 1500);
        addRoute(db, "Москва", "Санкт-Петербург", "20:00", 8, 1500);
        addRoute(db, "Москва", "Сочи", "08:00", 24, 2500);
        addRoute(db, "Москва", "Сочи", "20:00", 24, 2500);
        addRoute(db, "Москва", "Саратов", "08:00", 16, 1200);
        addRoute(db, "Москва", "Саратов", "20:00", 16, 1200);
        addRoute(db, "Санкт-Петербург", "Москва", "09:00", 8, 1500);
        addRoute(db, "Санкт-Петербург", "Сочи", "07:00", 28, 2800);
        addRoute(db, "Сочи", "Саратов", "10:00", 20, 2000);
        addRoute(db, "Казань", "Москва", "06:00", 12, 1800);
        addRoute(db, "Екатеринбург", "Москва", "08:00", 32, 3200);
    }

    private void addRoute(SQLiteDatabase db, String fromCity, String toCity, String departureTime, int travelTime, int price) {
        int fromCityId = getCityId(db, fromCity);
        int toCityId = getCityId(db, toCity);

        if (fromCityId != -1 && toCityId != -1) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_FROM_CITY_ID, fromCityId);
            values.put(COLUMN_TO_CITY_ID, toCityId);
            values.put(COLUMN_DEPARTURE_TIME, departureTime);
            values.put(COLUMN_TRAVEL_TIME, travelTime);
            values.put(COLUMN_PRICE, price);
            db.insert(TABLE_ROUTES, null, values);
        }
    }

    @SuppressLint("Range")
    private int getCityId(SQLiteDatabase db, String cityName) {
        Cursor cursor = db.query(TABLE_CITIES, new String[]{COLUMN_CITY_ID},
                COLUMN_CITY_NAME + " = ?", new String[]{cityName}, null, null, null);

        int cityId = -1;
        if (cursor.moveToFirst()) {
            cityId = cursor.getInt(cursor.getColumnIndex(COLUMN_CITY_ID));
        }
        cursor.close();
        return cityId;
    }

    // получение городов
    @SuppressLint("Range")
    public List<String> getAllCities() {
        List<String> cities = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_CITIES, new String[]{COLUMN_CITY_NAME},
                null, null, null, null, COLUMN_CITY_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                cities.add(cursor.getString(cursor.getColumnIndex(COLUMN_CITY_NAME)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return cities;
    }

    // поискк маршрутов
    public List<MainActivity.BusTrip> findRoutes(String fromCity, String toCity, long date) {
        List<MainActivity.BusTrip> routes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT r.*, c1." + COLUMN_CITY_NAME + " as from_city_name, c2." + COLUMN_CITY_NAME + " as to_city_name " +
                "FROM " + TABLE_ROUTES + " r " +
                "INNER JOIN " + TABLE_CITIES + " c1 ON r." + COLUMN_FROM_CITY_ID + " = c1." + COLUMN_CITY_ID + " " +
                "INNER JOIN " + TABLE_CITIES + " c2 ON r." + COLUMN_TO_CITY_ID + " = c2." + COLUMN_CITY_ID + " " +
                "WHERE c1." + COLUMN_CITY_NAME + " = ? AND c2." + COLUMN_CITY_NAME + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{fromCity, toCity});

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") MainActivity.BusTrip trip = new MainActivity.BusTrip(
                        cursor.getString(cursor.getColumnIndex("from_city_name")),
                        cursor.getString(cursor.getColumnIndex("to_city_name")),
                        date,
                        cursor.getString(cursor.getColumnIndex(COLUMN_DEPARTURE_TIME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN_TRAVEL_TIME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN_PRICE))
                );
                routes.add(trip);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return routes;
    }

    // добавление в историю
    public long addToTripHistory(String fromCity, String toCity, String tripDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FROM_CITY, fromCity);
        values.put(COLUMN_TO_CITY, toCity);
        values.put(COLUMN_TRIP_DATE, tripDate);

        return db.insert(TABLE_TRIP_HISTORY, null, values);
    }

    // получение истории поездок
    public List<TripHistory> getTripHistory() {
        List<TripHistory> history = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_TRIP_HISTORY,
                new String[]{COLUMN_HISTORY_ID, COLUMN_FROM_CITY, COLUMN_TO_CITY, COLUMN_TRIP_DATE, COLUMN_BOOKING_DATE},
                null, null, null, null, COLUMN_BOOKING_DATE + " DESC");

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TripHistory trip = new TripHistory(
                        cursor.getInt(cursor.getColumnIndex(COLUMN_HISTORY_ID)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_FROM_CITY)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_TO_CITY)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_TRIP_DATE)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_BOOKING_DATE))
                );
                history.add(trip);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return history;
    }

    // история поездок
    public static class TripHistory {
        private int historyId;
        private String fromCity;
        private String toCity;
        private String tripDate;
        private String bookingDate;

        public TripHistory(int historyId, String fromCity, String toCity, String tripDate, String bookingDate) {
            this.historyId = historyId;
            this.fromCity = fromCity;
            this.toCity = toCity;
            this.tripDate = tripDate;
            this.bookingDate = bookingDate;
        }

        // геттеры
        public int getHistoryId() { return historyId; }
        public String getFromCity() { return fromCity; }
        public String getToCity() { return toCity; }
        public String getTripDate() { return tripDate; }
        public String getBookingDate() { return bookingDate; }
    }
}